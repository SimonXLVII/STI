@extends('layouts.app')

@section('title', $categ->categ)
@section('content')
    <h2>{{$categ->categ}}</h2>

        <div class="cat_body">
            @foreach ($products as $product)
                @if ($product->categ_id == $categ->id)
                    <div class="card">
                        <img src="/storage/{{$product->image}}" class="card-img" alt="цепь}}">
                        <div class="card-body">
                            <h5 class="card-title">{{$product->title}}</h5>
                            <p class="card-text">
                                {{$product->price}} ₽
                            </p>
                            <div class="card-btns">
                                @if ($product->count == 0)
                                    <span class="btn btn-primary btn-empty">Товар закончился</span>
                                @else
                                    <a href="{{route('product', [$product->categ->url, $product->id])}}" class="btn btn-primary">Перейти к товару</a>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
            <div class="pag">{{$products->onEachSide(1)->links()}}</div>
        </div>
        <button id="back" name="back" class="back btn btn-primary">Назад</button>
@endsection