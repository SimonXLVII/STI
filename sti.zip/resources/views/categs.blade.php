@extends('layouts.app')

@section('title', 'Категории')
@section('content')
    <h2>Категории</h2>

    <div class="categs-body">

        @foreach ($categs as $categ)

            <div>
                <img src="/storage/{{$categ->image}}" alt="цепь" class="categ-img">
                <a href="{{route('categ', $categ->url)}}" class="btn btn-primary btn-categs">{{$categ->categ}}</a>
            </div>

        @endforeach

    </div>
@endsection