@extends('layouts.app')

@section('title', 'Заказы')
@section('content')
    <h2>Заказы</h2>
        <div class="order">
            <div class="order-head">
                <span>Название</span>
                <span>Цена, ₽</span>
                <span>Количество, шт</span>
                <span>Сумма, ₽</span>
                <span>Статус заказа</span>
                <span>Имя заказчика</span>
                <span>Фамилия заказчика</span>
                <span>Телефон</span>
                <span>Почта</span>
                <span>Адрес доставки</span>
                <span>Изменить/удалить</span>
            </div>
            <div class="order-body">
                @foreach ($orders as $order)
                    @if ($order->status_id != 1)
                        <form action="{{route('order-update', $order->id)}}" method="POST" enctype="multipart/form-data">
                            @csrf
                                <div class="order-item">
                                    <span class="order-title">
                                        {{$order->product->title}}
                                    </span>
                                    <span class="order-price">
                                        {{$order->product->price}}
                                    </span>
                                    <span class="order-count">
                                        <input type="number" id="input_count" name="input_count" min="{{$order->count}}" max="{{$order->count}}" value="{{$order->count}}" class="input_count" disabled>
                                    </span>
                                    <span class="order-sum">
                                        <input type="number" id="input_sum" name="input_sum" min="{{$order->sum}}" max="{{$order->sum}}" value="{{$order->sum}}" class="input_sum" disabled>
                                    </span>
                                    <span class="order-status">
                                        <select name="status" class="edit_view_select">
                                            @foreach ($statuses as $status)
                                                @if ($status->status == $order->status->status)
                                                    <option value="{{$order->status->id}}" selected>{{$order->status->status}}</option>
                                                @else
                                                    <option value="{{$status->id}}">{{$status->status}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </span>
                                    <span class="order-user">
                                        {{$order->name}}
                                    </span>
                                    <span class="order-user">
                                        {{$order->surname}}
                                    </span>
                                    <span class="order-user">
                                        {{$order->phone}}
                                    </span>
                                    <span class="order-user">
                                        {{$order->email}}
                                    </span>
                                    <span class="order-user">
                                        {{$order->address}}
                                    </span>
                                    <div class="order-title">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submitUpdate">Изменить</button>
                        </form>
                        <form action="{{route('order-delete', $order->id)}}" method="POST" enctype="multipart/form-data">
                            @csrf
                                        <button type="submit" class="btn btn-primary btn-sm" name="submitUpdate">Удалить</button>
                                    </div>
                                </div>
                        </form>
                    @endif
                @endforeach
            </div>
        </div>
@endsection