@extends('layouts.app')

@section('title', 'Изменить товара')
@section('content')
    <h2>Изменить товар "{{$product->title}}"</h2>
    
    <form action="{{route('update', $product->id)}}" method="POST" enctype="multipart/form-data" class="submit-form" required>
        @csrf
            <div>
                <label for="title">Название товара</label>
                <input type="text" id="title" name="title" minlength="10" maxlength="50" value="{{$product->title}}" placeholder="{{$product->title}}" class="submit_title" required>
            </div>

            <div>
                <label for="descr">Описание товара</label>
                <textarea id="descr" name="descr" minlength="100" maxlength="500" class="submit_descr" rows="6" required>{{$product->descr}}</textarea>
            </div>

            <div>
                <label for="price">Цена товара</label>
                <input type="number" id="price" name="price" maxlength="3" min="100" max="999" value="{{$product->price}}" placeholder="{{$product->price}}" class="submit_price">
            </div>

            <div>
                <label for="count">Количество товара</label>
                <input type="number" id="count" name="count" maxlength="2" min="0" max="20" value="{{$product->count}}" placeholder="{{$product->count}}" class="submit_count">
            </div>

            <div>
                <label for="image">Изображение товара</label>
                <input type="file" id="image" name="image" value="{{$product->image}}" class="submit_image" accept="image/jpeg, image/jpg, image/png">
            </div>

            <div class="edit_select_div">
                <label for="categ">Выберите категорию</label>
                <select name="categ" class="edit_view_select">
                    @foreach ($categs as $categ)
                        <option value="{{$categ->id}}">{{$categ->categ}}</option>
                    @endforeach
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary edit-form-btn" id="submitUpdate" name="submitUpdate">Изменить</button>
        </form>

        <form action="{{route('delete', $product->id)}}" method="POST" enctype="multipart/form-data">
            @csrf
            <button type="submit" class="btn btn-primary edit-form-btn" id="btn-delete" name="btn-delete">Удалить</button>
        </form>

        <button id="back" name="back" class="back btn btn-primary">Назад</button>
@endsection