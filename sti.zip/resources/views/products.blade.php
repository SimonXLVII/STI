@extends('layouts.app')

@section('title', 'Изменить/удалить товар')
@section('content')
    <h2>Изменить/удалить товар</h2>

        <div class="cat_body">
            @foreach ($products as $product)
                <div class="card">
                    <img src="/storage/{{$product->image}}" class="card-img" alt="цепь}}">
                    <div class="card-body">
                        <h5 class="card-title">{{$product->title}}</h5>
                        <p class="card-text">
                            {{$product->price}} ₽
                        </p>
                        <div class="card-btns">
                            @if ($product->count == 0)
                                <a href="{{route('product', [$product->categ->url, $product->id])}}" class="btn btn-primary admin-btn-empty">Товар закончился</a>
                            @else
                                <a href="{{route('product', [$product->categ->url, $product->id])}}" class="btn btn-primary">Перейти к товару</a>
                            @endif
                            <a href="{{route('edit', $product->id)}}" class="btn btn-primary">Edit/delete</a>
                        </div>
                    </div>
                </div>
            @endforeach
            <div class="pag">{{$products->onEachSide(1)->links()}}</div>
        </div>
@endsection