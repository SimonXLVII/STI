@extends('layouts.app')

@section('title', 'Контакты')
@section('content')
    <h2>Контакты</h2>

    <div class="contatcs-body">
        <span>Адрес: ул. Кирова, 1, Челябинск, Челябинская обл., Россия</span>
        <span>Телефон: 8-(800)-555-35-35</span>
        <span>Почта: sti.chains@mail.ru</span>
        <span>VK - <a href="https://m.vk.com" class="contact">https://m.vk.com</a></span>
        <span>Telegram - <a href="https://web.telegram.org" class="contact">https://web.telegram.org</a></span>
    </div>
@endsection