@extends('layouts.app')

@section('title', 'Добавление товара')
@section('content')
    <h2>Добавление товара</h2>
    
    <form action="{{route('insert')}}" method="POST" enctype="multipart/form-data" class="submit-form">
        @csrf
            <div>
                <label for="title">Название товара</label>
                <input type="text" id="title" name="title" minlength="10" maxlength="50" value="" placeholder="Введите название товара..." class="submit_title" required>
            </div>

            <div>
                <label for="descr">Описание товара</label>
                <textarea id="descr" name="descr" minlength="100" maxlength="500" class="submit_descr" rows="6" required></textarea>
            </div>

            <div>
                <label for="price">Цена товара</label>
                <input type="number" id="price" name="price" maxlength="3" min="100" max="999" value="100" placeholder="Введите цену товара..." class="submit_price">
            </div>

            <div>
                <label for="count">Количество товара</label>
                <input type="number" id="count" name="count" maxlength="2" min="1" max="20" value="1" placeholder="Введите количество товара..." class="submit_count">
            </div>

            <div>
                <label for="image">Изображение товара</label>
                <input type="file" id="image" name="image" class="submit_image" accept="image/jpeg, image/jpg, image/png" required>
            </div>

            <div class="edit_select_div">
                <label for="categ">Выберите категорию</label>
                <select name="categ" class="edit_view_select">
                    @foreach ($categs as $categ)
                        <option value="{{$categ->id}}">{{$categ->categ}}</option>
                    @endforeach
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary edit-form-btn" name="submitUpdate">Добавить</button>
        </form>
        <button id="back" name="back" class="back btn btn-primary">Назад</button>
@endsection