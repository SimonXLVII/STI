@extends('layouts.app')

@section('title', 'Админ-панель')
@section('content')
    <h2>Админ-панель</h2>

    <div class="admin-btns">
        <a class="btn btn-primary admin-btn" href="{{route('index')}}">Главная</a>
        <a class="btn btn-primary admin-btn" href="{{route('create')}}">Добавить товар</a>
        <a class="btn btn-primary admin-btn" href="{{route('products')}}">Изменить/удалить товар</a>
        <a class="btn btn-primary admin-btn" href="{{route('orders')}}">Заказы</a>
        <a class="btn btn-primary admin-btn" href="">Выход</a>
    </div>
@endsection