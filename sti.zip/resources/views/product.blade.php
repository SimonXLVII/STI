@extends('layouts.app')

@section('title', $product->title)
@section('content')
    <h2>{{$product->categ->categ}}</h2>

    <div class="prod-body">
        <div class="prod">
            <img src="/storage/{{$product->image}}" alt="цепь" class="prod-img">
            <h4>{{$product->title}}</h4>
            <p>{{$product->descr}}</p>
            <p>Цена: {{$product->price}} ₽</p>
            <p>Количество на складе: {{$product->count}} шт.</p>
            <div class="prod-btns">
                <div class="input-group prod-btn">
                    @if ($product->count == 0)
                        <span class="btn btn-primary btn-empty">Товар закончился</span>
                    @else
                        <form action="{{route('basket-add', [$product->categ->url, $product->id])}}">
                            @csrf
                            <button type="submit" id="btn_order" name="btn_order" class="btn btn-primary btn_order">Добавить в корзину</button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <button id="back" name="back" class="back btn btn-primary">Назад</button>
@endsection