@extends('layouts.app')

@section('title', 'Авторизация')
@section('content')
    <h2>Авторизация</h2>

    <div class="auth">
        <form action="{{route('login-check')}}" method="POST" enctype="multipart/form-data">
            @csrf
                <div class="auth-email">
                    <label for="address">Почта</label>
                    <input type="email" id="email" name="email" placeholder="Введите почту..." value="" class="form-control text-center auth-input">
                </div>
                <div class="auth-password">
                    <label for="address">Пароль</label>
                    <input type="password" id="password" name="password" placeholder="Введите пароль..." value="" class="form-control text-center">
                </div>
                @error("errorLogin")
                    <p><small class="text-danger">{{$message}}</small></p>
                @enderror
                <div class="btn-auth">
                    <button type="submit" id="btn-auth" name="btn-auth" class="btn btn-primary btn-auth">Авторизоваться</button>
                </div>
        </form>
    </div>
    <button id="back" name="back" class="back btn btn-primary back-btn-auth">Назад</button>
@endsection