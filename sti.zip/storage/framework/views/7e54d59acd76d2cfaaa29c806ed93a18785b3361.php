

<?php $__env->startSection('title', 'Категории'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Категории</h2>

    <div class="categs-body">

        <?php $__currentLoopData = $categs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div>
                <img src="/storage/<?php echo e($categ->image); ?>" alt="цепь" class="categ-img">
                <a href="<?php echo e(route('categ', $categ->url)); ?>" class="btn btn-primary btn-categs"><?php echo e($categ->categ); ?></a>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0658103/domains/a0658103.xsph.ru/public_html/resources/views/categs.blade.php ENDPATH**/ ?>