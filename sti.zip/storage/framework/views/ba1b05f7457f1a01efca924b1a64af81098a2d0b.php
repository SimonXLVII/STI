

<?php $__env->startSection('title', 'Админ-панель'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Админ-панель</h2>

    <div class="admin-btns">
        <a class="btn btn-primary admin-btn" href="<?php echo e(route('index')); ?>">Главная</a>
        <a class="btn btn-primary admin-btn" href="<?php echo e(route('create')); ?>">Добавить товар</a>
        <a class="btn btn-primary admin-btn" href="<?php echo e(route('products')); ?>">Изменить/удалить товар</a>
        <a class="btn btn-primary admin-btn" href="<?php echo e(route('orders')); ?>">Заказы</a>
        <a class="btn btn-primary admin-btn" href="">Выход</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0658103/domains/a0658103.xsph.ru/public_html/resources/views/admin.blade.php ENDPATH**/ ?>