

<?php $__env->startSection('title', 'Авторизация'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Авторизация</h2>

    <div class="auth">
        <form action="#" method="POST" enctype="multipart/form-data">
            <div class="auth-email">
                <label for="address">Почта</label>
                <input type="text" id="phone" name="phone" placeholder="Введите почту..." value="" class="form-control text-center auth-input">
            </div>
            <div class="auth-password">
                <label for="address">Пароль</label>
                <input type="text" id="phone" name="phone" placeholder="Введите пароль..." value="" class="form-control text-center">
            </div>
            <div class="btn-auth">
                <button type="submit" id="btn-auth" name="btn-auth" class="btn btn-primary btn-auth">Авторизоваться</button>
            </div>
        </form>
    </div>
    <button id="back" name="back" class="back btn btn-primary back-btn-auth">Назад</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/auth.blade.php ENDPATH**/ ?>