

<?php $__env->startSection('title', 'Корзина'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Корзина</h2>
        <div class="basket">
            <div class="basket-head">
                <span>Название</span>
                <span>Цена, ₽</span>
                <span>Количество, шт</span>
                <span>Сумма, ₽</span>
            </div>
            <div class="basket-body">
                <?php if(count($orders) > 0): ?>
                    <form action="<?php echo e(route('basket-update')); ?>" id="basket-form" name="form" method="POST" enctype="multipart/form-data">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($order->status_id == 1): ?>
                                <?php echo csrf_field(); ?>
                                    <div class="basket-item">
                                        <input type="hidden" id="input_id_<?php echo e($order->id); ?>" name="input_id_<?php echo e($order->id); ?>" min="<?php echo e($order->id); ?>" max="<?php echo e($order->id); ?>" value="<?php echo e($order->id); ?>">
                                        <span class="basket-title">
                                            <?php echo e($order->product->title); ?>

                                        </span>
                                        <span class="basket-price">
                                            <input type="number" id="input_price_<?php echo e($order->id); ?>" name="input_price_<?php echo e($order->id); ?>" min="<?php echo e($order->product->price); ?>" max="<?php echo e($order->product->price); ?>" value="<?php echo e($order->product->price); ?>" class="input_price" disabled>
                                        </span>
                                        <span class="basket-count">
                                            <input type="number" id="input_count_<?php echo e($order->id); ?>" name="input_count_<?php echo e($order->id); ?>" min="0" max="<?php echo e($order->product->count); ?>" value="1" class="input_count">
                                            <p class="message" style="display: none;">При количестве 0 товар будет удалён из заказов!</p>
                                        </span>
                                        <span class="basket-sum">
                                            <input type="number" id="input_sum_<?php echo e($order->id); ?>" name="input_sum_<?php echo e($order->id); ?>" max="<?php echo e($order->product->count * $order->product->price); ?>" value="" class="input_sum">
                                        </span>
                                    </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="client-form">
                                <label for="client-name">Ваше имя</label>
                                <input type="text" id="client-name" name="client-name" class="client-name" required>

                                <label for="client-surname">Ваша фамилия</label>
                                <input type="text" id="client-surname" name="client-surname" class="client-surname" required>

                                <label for="client-phone">Ваш телефон (+7XXXXXXXXXX)</label>
                                <input type="tel" id="client-phone" name="client-phone" class="client-phone" required>

                                <label for="client-email">Ваша почта</label>
                                <input type="email" id="client-email" name="client-email" class="client-email" required>

                                <label for="client-address">Адрес доставки (улица, город)</label>
                                <input type="text" id="client-address" name="client-address" class="client-address" required>

                                <p>*Срок доставки - неделя (5 рабочих дней)</p>
                                <p>**Оплата при получении товара по адресу доставки</p>
                                <p>***Уведомления о заказе будут приходить на Ваш номер и почту</p>
                            </div>
                        <button type="submit" class="btn btn-primary btn-basket-order" id="submitUpdate" name="submitUpdate">Заказать</button>
                    </form>
                <?php else: ?>
                    <p class=""> Ваша корзина пуста!</p>
                <?php endif; ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0658103/domains/a0658103.xsph.ru/public_html/resources/views/basket.blade.php ENDPATH**/ ?>