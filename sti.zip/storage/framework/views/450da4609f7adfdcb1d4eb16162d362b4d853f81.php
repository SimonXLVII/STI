<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/global.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/header.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/nav.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/article.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/footer.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/products.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/product.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/categs.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/contacts.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/login.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/admin.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/submit.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/order.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/basket.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/client.css')); ?>" type="text/css">
</head>
<body>
    <header>
            <h1><a href="<?php echo e(route('index')); ?>" class="h1">STEEL WTH IT</a></h1>
        <nav>
            <span><a href="<?php echo e(route('categs')); ?>" class="navItem">Категории</a></span>
            <span><a href="<?php echo e(route('basket')); ?>" class="navItem">Корзина</a></span>
            <span><a href="<?php echo e(route('contacts')); ?>" class="navItem">Контакты</a></span>
        </nav>
    </header>

    <article>
        <?php echo $__env->yieldContent('content'); ?>
    </article>

    <footer>
        <span>VK - <a href="https://m.vk.com" class="footerItem">https://m.vk.com</a></span>
        <span>Telegram - <a href="https://web.telegram.org" class="footerItem">https://web.telegram.org</a></span>
        <span>STEEL WTH IT © 2001-2022</span>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('/js/links.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/sum.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/message.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/back.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/layouts/app.blade.php ENDPATH**/ ?>