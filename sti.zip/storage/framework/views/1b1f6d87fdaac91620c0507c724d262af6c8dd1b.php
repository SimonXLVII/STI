

<?php $__env->startSection('title', 'Контакты'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Контакты</h2>

    <div class="contatcs-body">
        <span>Адрес: ул. Кирова, 1, Челябинск, Челябинская обл., Россия</span>
        <span>Телефон: 8-(800)-555-35-35</span>
        <span>Почта: sti.chains@mail.ru</span>
        <span>VK - <a href="https://m.vk.com" class="contact">https://m.vk.com</a></span>
        <span>Telegram - <a href="https://web.telegram.org" class="contact">https://web.telegram.org</a></span>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0658103/domains/a0658103.xsph.ru/public_html/resources/views/contacts.blade.php ENDPATH**/ ?>