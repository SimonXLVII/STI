

<?php $__env->startSection('title', 'Изменить товара'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Изменить товар "<?php echo e($product->title); ?>"</h2>
    
    <form action="<?php echo e(route('update', $product->id)); ?>" method="POST" enctype="multipart/form-data" class="submit-form" required>
        <?php echo csrf_field(); ?>
            <div>
                <label for="title">Название товара</label>
                <input type="text" id="title" name="title" minlength="10" maxlength="50" value="<?php echo e($product->title); ?>" placeholder="<?php echo e($product->title); ?>" class="submit_title" required>
            </div>

            <div>
                <label for="descr">Описание товара</label>
                <textarea id="descr" name="descr" minlength="100" maxlength="500" class="submit_descr" rows="6" required><?php echo e($product->descr); ?></textarea>
            </div>

            <div>
                <label for="price">Цена товара</label>
                <input type="number" id="price" name="price" maxlength="3" min="100" max="999" value="<?php echo e($product->price); ?>" placeholder="<?php echo e($product->price); ?>" class="submit_price">
            </div>

            <div>
                <label for="count">Количество товара</label>
                <input type="number" id="count" name="count" maxlength="2" min="0" max="20" value="<?php echo e($product->count); ?>" placeholder="<?php echo e($product->count); ?>" class="submit_count">
            </div>

            <div>
                <label for="image">Изображение товара</label>
                <input type="file" id="image" name="image" value="<?php echo e($product->image); ?>" class="submit_image" accept="image/jpeg, image/jpg, image/png">
            </div>

            <div class="edit_select_div">
                <label for="categ">Выберите категорию</label>
                <select name="categ" class="edit_view_select">
                    <?php $__currentLoopData = $categs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categ->id); ?>"><?php echo e($categ->categ); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary edit-form-btn" id="submitUpdate" name="submitUpdate">Изменить</button>
        </form>

        <form action="<?php echo e(route('delete', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary edit-form-btn" id="btn-delete" name="btn-delete">Удалить</button>
        </form>

        <button id="back" name="back" class="back btn btn-primary">Назад</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/edit.blade.php ENDPATH**/ ?>