

<?php $__env->startSection('title', $product->title); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($product->categ->categ); ?></h2>

    <div class="prod-body">
        <div class="prod">
            <img src="/storage/<?php echo e($product->image); ?>" alt="цепь" class="prod-img">
            <h4><?php echo e($product->title); ?></h4>
            <p><?php echo e($product->descr); ?></p>
            <p>Цена: <?php echo e($product->price); ?> ₽</p>
            <p>Количество на складе: <?php echo e($product->count); ?> шт.</p>
            <div class="prod-btns">
                <div class="input-group prod-btn">
                    <?php if($product->count == 0): ?>
                        <span class="btn btn-primary btn-empty">Товар закончился</span>
                    <?php else: ?>
                        <form action="<?php echo e(route('basket-add', [$product->categ->url, $product->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" id="btn_order" name="btn_order" class="btn btn-primary btn_order">Добавить в корзину</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <button id="back" name="back" class="back btn btn-primary">Назад</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0658103/domains/a0658103.xsph.ru/public_html/resources/views/product.blade.php ENDPATH**/ ?>