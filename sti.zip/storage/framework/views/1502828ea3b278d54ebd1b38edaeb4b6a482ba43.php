

<?php $__env->startSection('title', 'Заказы'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Заказы</h2>
        <div class="order">
            <div class="order-head">
                <span>Название</span>
                <span>Цена, ₽</span>
                <span>Количество, шт</span>
                <span>Сумма, ₽</span>
                <span>Статус заказа</span>
                <span>Имя заказчика</span>
                <span>Фамилия заказчика</span>
                <span>Телефон</span>
                <span>Почта</span>
                <span>Адрес доставки</span>
                <span>Изменить/удалить</span>
            </div>
            <div class="order-body">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($order->status_id != 1): ?>
                        <form action="<?php echo e(route('order-update', $order->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <div class="order-item">
                                    <span class="order-title">
                                        <?php echo e($order->product->title); ?>

                                    </span>
                                    <span class="order-price">
                                        <?php echo e($order->product->price); ?>

                                    </span>
                                    <span class="order-count">
                                        <input type="number" id="input_count" name="input_count" min="<?php echo e($order->count); ?>" max="<?php echo e($order->count); ?>" value="<?php echo e($order->count); ?>" class="input_count" disabled>
                                    </span>
                                    <span class="order-sum">
                                        <input type="number" id="input_sum" name="input_sum" min="<?php echo e($order->sum); ?>" max="<?php echo e($order->sum); ?>" value="<?php echo e($order->sum); ?>" class="input_sum" disabled>
                                    </span>
                                    <span class="order-status">
                                        <select name="status" class="edit_view_select">
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($status->status == $order->status->status): ?>
                                                    <option value="<?php echo e($order->status->id); ?>" selected><?php echo e($order->status->status); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($status->id); ?>"><?php echo e($status->status); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </span>
                                    <span class="order-user">
                                        <?php echo e($order->name); ?>

                                    </span>
                                    <span class="order-user">
                                        <?php echo e($order->surname); ?>

                                    </span>
                                    <span class="order-user">
                                        <?php echo e($order->phone); ?>

                                    </span>
                                    <span class="order-user">
                                        <?php echo e($order->email); ?>

                                    </span>
                                    <span class="order-user">
                                        <?php echo e($order->address); ?>

                                    </span>
                                    <div class="order-title">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submitUpdate">Изменить</button>
                        </form>
                        <form action="<?php echo e(route('order-delete', $order->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary btn-sm" name="submitUpdate">Удалить</button>
                                    </div>
                                </div>
                        </form>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/orders.blade.php ENDPATH**/ ?>