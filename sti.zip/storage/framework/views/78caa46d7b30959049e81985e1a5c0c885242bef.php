

<?php $__env->startSection('title', 'Авторизация'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Авторизация</h2>

    <div class="auth">
        <form action="<?php echo e(route('login-check')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="auth-email">
                    <label for="address">Почта</label>
                    <input type="email" id="email" name="email" placeholder="Введите почту..." value="" class="form-control text-center auth-input">
                </div>
                <div class="auth-password">
                    <label for="address">Пароль</label>
                    <input type="password" id="password" name="password" placeholder="Введите пароль..." value="" class="form-control text-center">
                </div>
                <?php $__errorArgs = ["errorLogin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><small class="text-danger"><?php echo e($message); ?></small></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="btn-auth">
                    <button type="submit" id="btn-auth" name="btn-auth" class="btn btn-primary btn-auth">Авторизоваться</button>
                </div>
        </form>
    </div>
    <button id="back" name="back" class="back btn btn-primary back-btn-auth">Назад</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/login.blade.php ENDPATH**/ ?>