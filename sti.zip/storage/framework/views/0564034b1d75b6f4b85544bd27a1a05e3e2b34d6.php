

<?php $__env->startSection('title', 'Изменить/удалить товар'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Изменить/удалить товар</h2>

        <div class="cat_body">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <img src="/storage/<?php echo e($product->image); ?>" class="card-img" alt="цепь}}">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($product->title); ?></h5>
                        <p class="card-text">
                            <?php echo e($product->price); ?> ₽
                        </p>
                        <div class="card-btns">
                            <?php if($product->count == 0): ?>
                                <a href="<?php echo e(route('product', [$product->categ->url, $product->id])); ?>" class="btn btn-primary admin-btn-empty">Товар закончился</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('product', [$product->categ->url, $product->id])); ?>" class="btn btn-primary">Перейти к товару</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('edit', $product->id)); ?>" class="btn btn-primary">Edit/delete</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="pag"><?php echo e($products->onEachSide(1)->links()); ?></div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/products.blade.php ENDPATH**/ ?>