let back = document.querySelector('.back');

back.addEventListener("click", function () {
    window.history.go(-1);
});