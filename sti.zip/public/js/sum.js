let input_prices = document.querySelectorAll('.input_price'),
input_counts = document.querySelectorAll('.input_count'),
input_sums = document.querySelectorAll('.input_sum');

// цикл for
// индексы
// addEventListener('change')

for (let i = 0; i < input_sums.length; i++) {
    input_sums[i].value = input_counts[i].value * input_prices[i].value;
    input_sums[i].setAttribute("min", input_sums[i].value);
    input_sums[i].setAttribute("max", input_sums[i].value);
}

input_counts.forEach(input_count => {
    input_count.addEventListener('change', function() {
        for (let i = 0; i < input_sums.length; i++) {
            input_sums[i].value = input_counts[i].value * input_prices[i].value;
            input_sums[i].setAttribute("min", input_sums[i].value);
            input_sums[i].setAttribute("max", input_sums[i].value);
        }
    });
});