let forms = document.querySelectorAll('form');

forms.forEach(form => {
    form.addEventListener('keydown', function() {
        if(form.keyCode == 13) {
            form.preventDefault();
        }
    });
});