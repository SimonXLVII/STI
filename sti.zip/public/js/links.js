let header = document.querySelector('header'),
nav = document.querySelector('nav'),
footer = document.querySelector('footer'),
h1 = document.querySelector('.h1'),
navItems = document.querySelectorAll('.navItem'),
footerItems = document.querySelectorAll('.footerItem');

header.addEventListener('mouseover', function() {
    h1.style.color = "white";
    navItems.forEach(navItem => {
        navItem.style.color = "white";
    });
});
nav.addEventListener('mouseover', function() {
    h1.style.color = "white";
    navItems.forEach(navItem => {
        navItem.style.color = "white";
    });
});
footer.addEventListener('mouseover', function() {
    footerItems.forEach(footerItem => {
        footerItem.style.color = "white";
    });
});

header.addEventListener('mouseout', function() {
    h1.style.color = "black";
    navItems.forEach(navItem => {
        navItem.style.color = "black";
    });
});
nav.addEventListener('mouseout', function() {
    h1.style.color = "black";
    navItems.forEach(navItem => {
        navItem.style.color = "black";
    });
});
footer.addEventListener('mouseout', function() {
    footerItems.forEach(footerItem => {
        footerItem.style.color = "black";
    });
});