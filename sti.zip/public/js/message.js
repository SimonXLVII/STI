let inputs_count = document.querySelectorAll('.input_count'),
    messages = document.querySelectorAll('.message');

for (let i = 0; i < inputs_count.length; i++) {
    inputs_count[i].addEventListener('change', function() {
        if (inputs_count[i].value == 0) {
            messages[i].style.display = 'block';
        } else {
            messages[i].style.display = 'none';
        }
    });
}