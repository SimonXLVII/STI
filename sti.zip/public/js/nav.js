let nav = document.querySelector('nav');

nav.addEventListener('mouseover', function() {
    if (nav.style.opacity == 0) {
        nav.style.opacity = 1;
    } else {
        nav.style.opacity = 0;
    }
});