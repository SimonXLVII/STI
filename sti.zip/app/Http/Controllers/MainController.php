<?php

namespace App\Http\Controllers;

use App\Http\Requests\Auth\LoginRequest;
use App\Models\Categ;
use App\Models\Order;
use App\Models\Product;
use App\Models\Status;
use App\Models\User;
use App\Services\FileService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MainController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
        $products = Product::paginate(9)->withQueryString();
        return view('index', ['products' => $products]);
    }



    public function loginCheck(Request $request) {
        $user = User::where('id', 4)->first();

        $email = $request->input('email');
        $password = $request->input('password');

        if ($user->email == $email && $user->password == $password) {
            return view('admin');
        } else {
            return view('login');
        }
    }
    


    public function categs()
    {
        $categs = Categ::all();
        return view('categs', ['categs' => $categs]);
    }



    public function categ($url)
    {
        $categ = Categ::where('url', $url)->first();
        $products = Product::paginate(9)->withQueryString();

        return view('categ', ['categ' => $categ, 'products' => $products]);
    }
    


    public function product($categ, $id)
    {
        $product = Product::where('id', $id)->first();
        return view('product', ['product' => $product]);
    }
    


    public function orderAdd($id, Request $request)
    {
        $product = Product::where('id', $id)->first();
        $sum = $product->price * $request->input('count');

        $order = Order::create([
            'name'=>$request->input('name'),
            'surname'=>$request->input('surname'),
            'phone'=>$request->input('phone'),
            'email'=>$request->input('email'),
            'address'=>$request->input('address'),
            'count'=>$request->input('count'),
            'sum'=>$sum,
            'product_id'=>$product->id,
            'status_id'=>1
        ]);

        return redirect()->route('index');
    }
    


    public function insert(Request $request)
    {
        $path = FileService::uploadFile($request->file('image'));

        Product::create([
            'title'=>$request->input('title'),
            'descr'=>$request->input('descr'),
            'image'=>$path,
            'price'=>$request->input('price'),
            'count'=>$request->input('count'),
            'categ_id'=>$request->input('categ')
        ]);

        return redirect()->route('index');
    }
    


    public function products()
    {
        $products = Product::paginate(9)->withQueryString();

        return view('products', ['products' => $products]);
    }



    public function create()
    {
        $categs = Categ::all();

        return view('create', ['categs' => $categs]);
    }
    


    public function edit($id)
    {
        $product = Product::where('id', $id)->first();
        $categs = Categ::all();

        return view('edit', ['product' => $product, 'categs' => $categs]);
    }
    


    public function update($id, Request $request)
    {
        $product = Product::where('id', $id)->first();

        $path = FileService::updateFile($request->file('image'), $product->image);

        Product::where('id', $id)
            ->update([
                'title'=>$request->input('title'),
                'descr'=>$request->input('descr'),
                'image'=>$path,
                'price'=>$request->input('price'),
                'count'=>$request->input('count'),
                'categ_id'=>$request->input('categ')
            ]);

        return redirect()->route('products');
    }
    


    public function delete($id)
    {
        $product = Product::where('id', $id)->first();

        FileService::deleteFile($product->image);

        $product->delete();

        return redirect()->route('products');
    }



    public function basket() {
        $orders = Order::where('status_id', 1)->get();

        return view('basket', ['orders' => $orders]);
    }



    public function basketAdd($categ, $id) {
        $product = Product::where('id', $id)->first();

        Order::create([
            'name' => "Новый пользователь",
            'surname' => "Новый пользователь",
            'phone' => "Новый пользователь",
            'email' => "Новый пользователь",
            'address' => "Новый пользователь",
            'count' => 1,
            'sum' => $product->price,
            'product_id' => $product->id,
            'status_id' => 1,
        ]);
        
        $orders = Order::where('status_id', 1)->get();

        return redirect()->route('product', [$product->categ->url, $product->id]);
    }



    public function basketUpdate(Request $request) {
        $datas = $request->all();

        $id = 0;
        $count = 0;
        $sum = 0;
        $status_id = 2;
        $arr = ['client-name', 'client-surname', 'client-phone', 'client-email', 'client-address'];

        $i = 0;
        foreach ($datas as $k => $v) {
            if ($i != 0 && $k != "submitUpdate" && !in_array($k, $arr)) {
                if ($i == 1) {
                    $id = $v;
                } elseif($i == 2) {
                    if ($v == 0) {
                        $order = Order::where('id', $id)->first();
                        $order->delete();
                    } else {
                        $count = $v;
                    }
                } else {
                    $sum = $v;

                    Order::where('id', $id)
                        ->update([
                            'name' => $request->input('client-name'),
                            'surname' => $request->input('client-surname'),
                            'phone' => $request->input('client-phone'),
                            'email' => $request->input('client-email'),
                            'address' => $request->input('client-address'),
                            'count' => $count,
                            'sum' => $sum,
                            'status_id' => $status_id,
                        ]);

                    $i = 0;
                }
            }

            $i++;
        }
        
        return redirect()->route('basket');
    }



    public function orders() {
        $orders = Order::all();
        $statuses = Status::all();

        return view('orders', ['orders' => $orders, 'statuses' => $statuses]);
    }



    public function orderUpdate($id, Request $request) {
        $order = Order::where('id', $id)->first();

        $count = 0;
        $sum = 0;
        
        if ($request->input('input_sum') == null) {
            $sum = $order->sum;
        } else {
            $sum = $request->input('input_sum');
        }

        if ($request->input('input_count') == null) {
            $count = $order->count;
        } else {
            $count = $request->input('input_count');
            $sum = $count * $order->product->price;
        }
        
        if ($request->input('status') == null) {
            $status = 2;
        } else {
            $status = $request->input('status');
        }

        if ($status > 1) {
            $order->product->price -= $count;
        } else {
            $order->product->price += $count;
        }

        Order::where('id', $id)
            ->update([
                'count' => $count,
                'sum' => $sum,
                'status_id' => $status,
            ]);
        
        return redirect()->route('orders');
    }



    public function orderDelete($id) {
        $order = Order::where('id', $id)->first();

        if ($order->status_id != 6) {
            $order->product->price += $order->count;
        }

        $order->delete();
        
        return redirect()->route('orders');
    }
}
