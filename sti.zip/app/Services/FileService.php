<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;

class FileService
{
    public static function uploadFile($file, $defaultFile = 'яц1.jpg', $folder='/')
    {
        if ($file !== null){
            $path = $file->store($folder, 'public');
        } else {
            $path = $defaultFile;
        }

        return $path;
    }

    public static function updateFile($file , $previousFile, $folder="/", $disk="public/")
    {
        $path = $disk.$previousFile;
        if($file !== null){
            Storage::delete($path);
            $path = $file->store($folder, 'public');
        }else{
            $path = $previousFile;
        }
        return $path;
    }

    public static function deleteFile($file, $folder='public/')
    {
        $path=$folder.$file;

        if (Storage::exists($path)) {
            Storage::delete($path);
        }
    }
}
