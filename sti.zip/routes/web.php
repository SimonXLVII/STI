<?php

use App\Http\Controllers\MainController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [MainController::class, 'index'])->name('index');

Route::get('/basket', [MainController::class, 'basket'])->name('basket');

Route::get('/contacts', function () {return view('contacts');})->name('contacts');

Route::get('/login', function() {return view('login');})->name('login');
Route::post('/login', [MainController::class, 'loginCheck'])->name('login-check');

Route::get('/masterskaya', [MainController::class, 'index'])->name('masterskaya');
Route::get('/admin', [MainController::class, 'index'])->name('admin');

Route::get('/masterskaya/create', [MainController::class, 'create'])->name('create');
Route::post('/masterskaya/create/insert', [MainController::class, 'insert'])->name('insert');

Route::get('/masterskaya/products', [MainController::class, 'products'])->name('products');

Route::get('/masterskaya/products/{edit}', [MainController::class, 'edit'])->name('edit');
Route::post('/masterskaya/products/{edit}/update', [MainController::class, 'update'])->name('update');
Route::post('/masterskaya/products/{edit}/delete', [MainController::class, 'delete'])->name('delete');

Route::get('/masterskaya/orders', [MainController::class, 'orders'])->name('orders');
Route::post('/masterskaya/orders/{order}/order_update', [MainController::class, 'orderUpdate'])->name('order-update');
Route::post('/masterskaya/orders/{order}/order_delete', [MainController::class, 'orderDelete'])->name('order-delete');

Route::get('/categs', [MainController::class, 'categs'])->name('categs');
Route::get('/{categ}', [MainController::class, 'categ'])->name('categ');
Route::get('/{categ}/{product}', [MainController::class, 'product'])->name('product');
Route::get('/{categ}/{product}/basket', [MainController::class, 'basketAdd'])->name('basket-add');

Route::post('/basket/basket_update', [MainController::class, 'basketUpdate'])->name('basket-update');
Route::post('/basket/{order}/basket_delete', [MainController::class, 'orderDelete'])->name('basket-delete');

Route::post('/order/{product}', [MainController::class, 'orderAdd'])->name('order-add');